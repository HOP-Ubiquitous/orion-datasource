define(function() { return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./module.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../node_modules/tslib/tslib.es6.js":
/*!******************************************!*\
  !*** ../node_modules/tslib/tslib.es6.js ***!
  \******************************************/
/*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __createBinding, __exportStar, __values, __read, __spread, __spreadArrays, __spreadArray, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault, __classPrivateFieldGet, __classPrivateFieldSet, __classPrivateFieldIn */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__createBinding", function() { return __createBinding; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArray", function() { return __spreadArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldGet", function() { return __classPrivateFieldGet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldSet", function() { return __classPrivateFieldSet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldIn", function() { return __classPrivateFieldIn; });
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    if (typeof b !== "function" && b !== null)
        throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

var __createBinding = Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});

function __exportStar(m, o) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
}

function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

/** @deprecated */
function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

/** @deprecated */
function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
}

function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

var __setModuleDefault = Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}

function __classPrivateFieldGet(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}

function __classPrivateFieldSet(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
}

function __classPrivateFieldIn(state, receiver) {
    if (receiver === null || (typeof receiver !== "object" && typeof receiver !== "function")) throw new TypeError("Cannot use 'in' operator on non-object");
    return typeof state === "function" ? receiver === state : state.has(receiver);
}


/***/ }),

/***/ "./config.ts":
/*!*******************!*\
  !*** ./config.ts ***!
  \*******************/
/*! exports provided: Config */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Config", function() { return Config; });
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

var Config = /*#__PURE__*/function () {
  function Config($scope, $injector, $window) {
    var _this = this;

    _classCallCheck(this, Config);

    this.$window = $window;
    this.pageReady = false;
    this.version = '';

    if (this.current.id) {
      this.current.jsonData.url = this.current.url;
    } else {
      this.current = {
        type: 'orion-datasource',
        access: 'proxy'
      };
    }

    this.setGrafanaVersion(this.$window);
    this.pageReady = true;
    $scope.$watch('ctrl.current', function () {
      _this.setUrl();
    });
  }

  _createClass(Config, [{
    key: "setGrafanaVersion",
    value: function setGrafanaVersion(window) {
      var _v;

      try {
        _v = window.grafanaBootData.settings.buildInfo.version.split('.')[0];
      } catch (e) {
        console.error(e);
        _v = 5;
      }

      this.version = _v;
    }
  }, {
    key: "setUrl",
    value: function setUrl() {
      this.current.jsonData.url = this.current.url;
    }
  }]);

  return Config;
}();
Config.templateUrl = 'partials/config.html';

/***/ }),

/***/ "./datasource.ts":
/*!***********************!*\
  !*** ./datasource.ts ***!
  \***********************/
/*! exports provided: Datasource */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Datasource", function() { return Datasource; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../node_modules/tslib/tslib.es6.js");
/* harmony import */ var _utils_query_type__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/query-type */ "./utils/query-type.ts");
/* harmony import */ var _utils_grafana_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils/grafana-utils */ "./utils/grafana-utils.ts");
/* harmony import */ var _utils_fiware_scope__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils/fiware-scope */ "./utils/fiware-scope.ts");
/* harmony import */ var _utils_fiware_type__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils/fiware-type */ "./utils/fiware-type.ts");
/* harmony import */ var _utils_fiware_entity__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./utils/fiware-entity */ "./utils/fiware-entity.ts");
/* harmony import */ var _utils_metric_query__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./utils/metric-query */ "./utils/metric-query.ts");
/* harmony import */ var _utils_fiware_scope_collection__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./utils/fiware-scope-collection */ "./utils/fiware-scope-collection.ts");
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }









var Datasource = /*#__PURE__*/function () {
  Datasource.$inject = ["instanceSettings", "backendSrv", "templateSrv"];

  /** @ngInject */
  function Datasource(instanceSettings, backendSrv, templateSrv) {
    _classCallCheck(this, Datasource);

    this.backendSrv = backendSrv;
    this.templateSrv = templateSrv;
    this.name = instanceSettings.name;
    this.url = instanceSettings.url;
    this.id = instanceSettings.id;
    this.isHide = false;
    this.headers = {};
    this.orionPaginationLimit = instanceSettings.jsonData.orionPaginationLimit;
    this.fiwareService = instanceSettings.jsonData.fiwareService || Datasource.DEFAULT_SERVICE_HEADER;
    this.fiwareServicePath = instanceSettings.jsonData.fiwareServicePath || Datasource.DEFAULT_SERVICE_PATH_HEADER;
  }

  _createClass(Datasource, [{
    key: "getDecoded",
    value: function getDecoded(variable) {
      //@ts-ignore
      return this.templateSrv.replace(variable);
    }
  }, {
    key: "getDecodedScopedVar",
    value: function getDecodedScopedVar(variable, scopedVars) {
      return this.templateSrv.replace(variable, scopedVars);
    }
  }, {
    key: "doRequest",
    value: function doRequest(options) {
      return this.backendSrv.datasourceRequest(options);
    }
  }, {
    key: "getQueryStringOrionLimit",
    value: function getQueryStringOrionLimit() {
      return "limit=".concat(this.orionPaginationLimit);
    }
  }, {
    key: "query",
    value: function query(options) {
      var self = this;
      var promises = [];
      var secondaryEntitiesTables = [];
      var queriesCount = options.targets.length;

      try {
        var _loop = function _loop(i) {
          var selectedRequest = self.getDecodedScopedVar(options.targets[i].selectedRequest, options.scopedVars);
          var defaultFiwareService = options.targets[i].defaultFiwareService;
          var service = self.fiwareService;
          var servicePath = self.fiwareServicePath;

          if (!defaultFiwareService) {
            service = self.getDecodedScopedVar(options.targets[i].service, options.scopedVars);
            servicePath = self.getDecodedScopedVar(options.targets[i].servicePath, options.scopedVars);
          }

          var includeTime = options.targets[i].currentTimeColumn;
          var entityType = self.getDecodedScopedVar(options.targets[i].entityType, options.scopedVars);
          var entityId = self.getDecodedScopedVar(options.targets[i].entityId, options.scopedVars);
          var attributes = self.getDecodedScopedVar(options.targets[i].attributes, options.scopedVars);
          var queryFilter = self.getDecodedScopedVar(options.targets[i].queryFilter, options.scopedVars);
          var fiwareScope = new _utils_fiware_scope__WEBPACK_IMPORTED_MODULE_3__["FIWAREScope"](service, servicePath, entityType);
          var isHide = options.targets[i].hide;

          if (i > 0) {
            if (selectedRequest === _utils_query_type__WEBPACK_IMPORTED_MODULE_1__["QueryType"].Entities && !isHide) {
              promises.push(self.getGrafanaTableEntities(fiwareScope, entityId, includeTime, attributes, queryFilter).then(function (dataTable) {
                promises.push(Promise.resolve(secondaryEntitiesTables.push(dataTable.data[0])));
              }));
            } else {
              console.log('Ignored secondary query');
            }
          } else {
            return {
              v: Promise.all(promises).then(function () {
                var tableData;
                var secondaryTables = [];

                switch (selectedRequest) {
                  case _utils_query_type__WEBPACK_IMPORTED_MODULE_1__["QueryType"].Entities:
                    {
                      tableData = self.getGrafanaTableEntities(fiwareScope, entityId, includeTime, attributes, queryFilter);
                      secondaryTables = secondaryEntitiesTables;
                      break;
                    }
                }

                return tableData.then(function (tableData) {
                  if (isHide) {
                    _utils_grafana_utils__WEBPACK_IMPORTED_MODULE_2__["GrafanaUtils"].setEmptyGrafanaTable(tableData);
                  }

                  secondaryTables.forEach(function (secondaryTable) {
                    tableData.data.push(secondaryTable);
                  });
                  return tableData;
                });
              })
            };
          }
        };

        for (var i = queriesCount - 1; i >= 0; i--) {
          var _ret = _loop(i);

          if (_typeof(_ret) === "object") return _ret.v;
        }
      } catch (e) {
        console.log('Errors with updates: ' + e);
        return e;
      }
    }
  }, {
    key: "findMetricsEntitiesGrafana",
    value: function findMetricsEntitiesGrafana(query) {
      var self = this;
      var service = self.fiwareService;
      var servicePath = self.fiwareServicePath;

      if (!query.defaultFiwareHeaders) {
        service = query.fiwareService;
        servicePath = query.fiwareServicePath;
      }

      var fiwareScope = new _utils_fiware_scope__WEBPACK_IMPORTED_MODULE_3__["FIWAREScope"](self.getDecoded(service), self.getDecoded(servicePath), self.getDecoded(query.entityType));
      return self.getGrafanaListEntities(fiwareScope, '', Datasource.DEFAULT_ATTRIBUTES, '');
    }
  }, {
    key: "findMetricsAttributesGrafana",
    value: function findMetricsAttributesGrafana(query, dashboardVariable) {
      var self = this;
      var service = self.fiwareService;
      var servicePath = self.fiwareServicePath;

      if (!query.defaultFiwareHeaders) {
        service = query.fiwareService;
        servicePath = query.fiwareServicePath;
      }

      return self.getGrafanaListEntityAttributes(new _utils_fiware_scope__WEBPACK_IMPORTED_MODULE_3__["FIWAREScope"](this.getDecoded(service), this.getDecoded(servicePath), this.getDecoded(query.entityType)), dashboardVariable);
    }
  }, {
    key: "findMetricsTypesGrafana",
    value: function findMetricsTypesGrafana(query) {
      var self = this;
      var service = self.fiwareService;
      var servicePath = self.fiwareServicePath;

      if (!query.defaultFiwareHeaders) {
        service = query.fiwareService;
        servicePath = query.fiwareServicePath;
      }

      var fiwareScope = new _utils_fiware_scope__WEBPACK_IMPORTED_MODULE_3__["FIWAREScope"](self.getDecoded(service), self.getDecoded(servicePath), undefined);
      return self.getGrafanaListTypes(fiwareScope);
    }
  }, {
    key: "getGrafanaTableEntities",
    value: function getGrafanaTableEntities(fiwareScope, entityId, includeTime, attributes, queryFilter) {
      var self = this;
      var attributesArray = [];

      if (attributes !== Datasource.DEFAULT_ATTRIBUTES) {
        try {
          attributesArray = attributes.split(',');
        } catch (error) {
          attributesArray = [];
        }
      }

      var entitiesResponse = self.queryGetEntities(fiwareScope, entityId, attributes, queryFilter);
      return entitiesResponse.then(function (entitiesResponse) {
        var orionEntities = entitiesResponse.data;
        var fiwareEntityCollection = Datasource.getFiwareEntityCollection(fiwareScope, attributesArray, orionEntities);
        entitiesResponse.data = fiwareEntityCollection.getGrafanaTable(includeTime, attributes === Datasource.DEFAULT_ALL_ATTRIBUTES);
        return entitiesResponse;
      });
    }
  }, {
    key: "getGrafanaListEntities",
    value: function getGrafanaListEntities(fiwareScope, entityId, attributes, queryFilter) {
      var self = this;
      var attributesArray = [];

      if (attributes !== Datasource.DEFAULT_ATTRIBUTES) {
        try {
          attributesArray = attributes.split(',');
        } catch (error) {
          attributesArray = [];
        }
      }

      var entitiesResponse = self.queryGetEntities(fiwareScope, entityId, attributes, queryFilter);
      return entitiesResponse.then(function (entitiesResponse) {
        var orionEntities = entitiesResponse.data;
        var fiwareEntityCollection = Datasource.getFiwareEntityCollection(fiwareScope, attributesArray, orionEntities);
        return fiwareEntityCollection.getGrafanaList();
      });
    }
  }, {
    key: "queryGetEntities",
    value: function queryGetEntities(fiwareScope, entityId, attributes, queryFilter) {
      var self = this;
      var url = self.url + Datasource.ORION_URL_ENTITIES;

      if (entityId === Datasource.DEFAULT_TYPE_ALL_ENTITIES) {
        entityId = '';
      }

      if (entityId !== undefined && entityId !== '') {
        url += '/' + entityId;
      }

      var queryParams = [];
      queryParams.push('options=dateModified');

      if (fiwareScope.type !== Datasource.DEFAULT_TYPE_ALL_ENTITIES) {
        queryParams.push('type=' + fiwareScope.type);
      }

      if (attributes !== Datasource.DEFAULT_ATTRIBUTES && attributes !== Datasource.DEFAULT_ALL_ATTRIBUTES) {
        queryParams.push('attrs=' + attributes);
      }

      if (queryFilter !== undefined && queryFilter !== '') {
        queryParams.push('q=' + queryFilter);
      }

      if (this.orionPaginationLimit !== undefined) {
        queryParams.push(this.getQueryStringOrionLimit());
      }

      if (queryParams.length > 0) {
        url += '?';
      }

      queryParams.forEach(function (param) {
        url += param + '&';
      });
      return self.doRequest({
        url: url,
        headers: _utils_fiware_scope__WEBPACK_IMPORTED_MODULE_3__["FIWAREScope"].getFiwareHeaders(fiwareScope.service, fiwareScope.servicePath),
        method: 'GET'
      }).then(function (entitiesResponse) {
        if (entitiesResponse.data === undefined) {
          entitiesResponse.data = [];
        } else if (entityId !== undefined && entityId !== '' && entityId !== Datasource.DEFAULT_TYPE_ALL_ENTITIES) {
          entitiesResponse.data = [entitiesResponse.data];
        }

        var collator = new Intl.Collator('es', {
          numeric: true,
          sensitivity: 'base'
        });
        entitiesResponse.data = entitiesResponse.data.sort(function (entityA, entityB) {
          return collator.compare(entityA.id, entityB.id);
        });
        return entitiesResponse;
      }, function (errorResponse) {
        errorResponse.data = [];
        return errorResponse;
      });
    }
  }, {
    key: "getGrafanaListTypes",
    value: function getGrafanaListTypes(fiwareScope) {
      var promiseTypesResponse = this.queryGetTypes(fiwareScope);
      return promiseTypesResponse.then(function (typesResponse) {
        var fiwareTypeCollection = new _utils_fiware_type__WEBPACK_IMPORTED_MODULE_4__["FIWARETypeCollection"](fiwareScope.service, fiwareScope.servicePath, typesResponse.data);
        return fiwareTypeCollection.getGrafanaList();
      });
    }
  }, {
    key: "queryGetTypes",
    value: function queryGetTypes(fiwareScope) {
      var self = this;
      return self.doRequest({
        url: self.url + Datasource.ORION_URL_TYPES,
        headers: _utils_fiware_scope__WEBPACK_IMPORTED_MODULE_3__["FIWAREScope"].getFiwareHeaders(fiwareScope.service, fiwareScope.servicePath),
        method: 'GET'
      }).then(function (typesResponse) {
        return typesResponse;
      }, function (errorResponse) {
        errorResponse.data = [];
        return errorResponse;
      });
    }
  }, {
    key: "getGrafanaListEntityAttributes",
    value: function getGrafanaListEntityAttributes(fiwareScope, dashboardVariable) {
      var self = this;

      if (fiwareScope.type === Datasource.DEFAULT_TYPE_ALL_ENTITIES) {
        if (dashboardVariable) {
          return Promise.resolve(_utils_grafana_utils__WEBPACK_IMPORTED_MODULE_2__["GrafanaUtils"].getGrafanaList(['location', 'latitude', 'longitude']));
        } else {
          return Promise.resolve(_utils_grafana_utils__WEBPACK_IMPORTED_MODULE_2__["GrafanaUtils"].getGrafanaList(['location,latitude,longitude']));
        }
      }

      var promiseEntitiesReponse = self.queryGetEntities(fiwareScope, '', Datasource.DEFAULT_ALL_ATTRIBUTES, '');
      return promiseEntitiesReponse.then(function (entitiesResponse) {
        var orionEntities = entitiesResponse.data;
        var fiwareEntityCollection = Datasource.getFiwareEntityCollection(fiwareScope, [], orionEntities);

        if (!fiwareEntityCollection.isEmpty()) {
          var columnArray = fiwareEntityCollection.getColumnHeaders(false);

          if (dashboardVariable) {
            return _utils_grafana_utils__WEBPACK_IMPORTED_MODULE_2__["GrafanaUtils"].getGrafanaList(columnArray);
          } else {
            var columnString = '';
            columnArray.forEach(function (column) {
              columnString += column + ',';
            });
            columnString = columnString.substring(0, columnString.length - 1);
            return _utils_grafana_utils__WEBPACK_IMPORTED_MODULE_2__["GrafanaUtils"].getGrafanaList([columnString]);
          }
        } else {
          return _utils_grafana_utils__WEBPACK_IMPORTED_MODULE_2__["GrafanaUtils"].getGrafanaList([]);
        }
      });
    }
  }, {
    key: "getGrafanaListAttributeValue",
    value: function getGrafanaListAttributeValue(fiwareScope, id, attribute, queryFilter) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var self, attributes, fiwareEntityCollection;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                self = this;
                attributes = attribute.split(',');
                _context.next = 4;
                return self.queryAttributeValuesCollection(fiwareScope, id, attribute, queryFilter);

              case 4:
                fiwareEntityCollection = _context.sent;

                if (!fiwareEntityCollection.isEmpty()) {
                  _context.next = 7;
                  break;
                }

                return _context.abrupt("return", _utils_grafana_utils__WEBPACK_IMPORTED_MODULE_2__["GrafanaUtils"].getGrafanaList([]));

              case 7:
                return _context.abrupt("return", fiwareEntityCollection.getAttributeValuesGrafanaList(attributes[0]));

              case 8:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "getGrafanaListAttributeValueAsMapping",
    value: function getGrafanaListAttributeValueAsMapping(fiwareScope, id, attribute, queryFilter) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var self, attributes, fiwareEntityCollection;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                self = this;
                attributes = attribute.split(',');
                _context2.next = 4;
                return self.queryAttributeValuesCollection(fiwareScope, id, attribute, queryFilter);

              case 4:
                fiwareEntityCollection = _context2.sent;

                if (!fiwareEntityCollection.isEmpty()) {
                  _context2.next = 7;
                  break;
                }

                return _context2.abrupt("return", _utils_grafana_utils__WEBPACK_IMPORTED_MODULE_2__["GrafanaUtils"].getGrafanaList([]));

              case 7:
                return _context2.abrupt("return", fiwareEntityCollection.getAttributeValuesGrafanaListMappingId(attributes[0]));

              case 8:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
    }
  }, {
    key: "getGrafanaListAttributeValueAsList",
    value: function getGrafanaListAttributeValueAsList(fiwareScope, id, attribute, queryFilter) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var self, attributes, fiwareEntityCollection;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                self = this;
                attributes = attribute.split(',');
                _context3.next = 4;
                return self.queryAttributeValuesCollection(fiwareScope, id, attribute, queryFilter);

              case 4:
                fiwareEntityCollection = _context3.sent;

                if (!fiwareEntityCollection.isEmpty()) {
                  _context3.next = 7;
                  break;
                }

                return _context3.abrupt("return", _utils_grafana_utils__WEBPACK_IMPORTED_MODULE_2__["GrafanaUtils"].getGrafanaList([]));

              case 7:
                return _context3.abrupt("return", fiwareEntityCollection.getAttributeValueAsGrafanaList(attributes[0]));

              case 8:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));
    }
  }, {
    key: "queryAttributeValuesCollection",
    value: function queryAttributeValuesCollection(fiwareScope, id, attribute, queryFilter) {
      var self = this;
      var attributes = attribute.split(',');
      var entitiesResponse = self.queryGetEntities(fiwareScope, id, attribute, queryFilter);
      return entitiesResponse.then(function (entitiesResponse) {
        var orionEntities = entitiesResponse.data;
        return new _utils_fiware_entity__WEBPACK_IMPORTED_MODULE_5__["FIWAREEntityCollection"](fiwareScope.service, fiwareScope.servicePath, attributes, orionEntities);
      });
    }
  }, {
    key: "getGrafanaListFiwareServices",
    value: function getGrafanaListFiwareServices() {
      var promiseFiwareServicesResponse = this.queryGetAdminMetrics();
      return promiseFiwareServicesResponse.then(function (fiwareServicesResponse) {
        var fiwareServicesCollection = new _utils_fiware_scope_collection__WEBPACK_IMPORTED_MODULE_7__["FiwareServicesCollection"](fiwareServicesResponse.data);
        return fiwareServicesCollection.getGrafanaList();
      });
    }
  }, {
    key: "getGrafanaListFiwareServicePaths",
    value: function getGrafanaListFiwareServicePaths(fiwareService) {
      var promiseFiwareServicePathsResponse = this.queryGetAdminMetrics();
      return promiseFiwareServicePathsResponse.then(function (fiwareServicePathsResponse) {
        var fiwareServicePathsCollection = new _utils_fiware_scope_collection__WEBPACK_IMPORTED_MODULE_7__["FiwareServicePathsCollection"](fiwareService, fiwareServicePathsResponse.data);
        return fiwareServicePathsCollection.getGrafanaList();
      });
    }
  }, {
    key: "queryGetAdminMetrics",
    value: function queryGetAdminMetrics() {
      var self = this;
      return self.doRequest({
        url: self.url + Datasource.ORION_ADMIN_METRICS,
        headers: {},
        method: 'GET'
      }).then(function (typesResponse) {
        return typesResponse;
      }, function (errorResponse) {
        errorResponse.data = [];
        return errorResponse;
      });
    }
  }, {
    key: "metricFindQuery",
    value: function metricFindQuery(query) {
      var self = this;
      var interpolated = self.templateSrv.replace(query, {});
      var metricQueryJSON = undefined;
      var metricQuery = undefined;

      try {
        metricQueryJSON = JSON.parse(interpolated);
        metricQuery = _utils_metric_query__WEBPACK_IMPORTED_MODULE_6__["MetricQuery"].parseFromJSON(metricQueryJSON);
      } catch (e) {
        console.log('Legacy mode, there is a new metric query format');
      }

      if (metricQuery !== undefined) {
        if (!metricQuery.isComplete()) {
          throw new TypeError('Incomplete Query');
        }

        switch (metricQuery.request) {
          case _utils_metric_query__WEBPACK_IMPORTED_MODULE_6__["MetricQueryType"].Entities:
            return Promise.resolve(self.getGrafanaListEntities(metricQuery.fiwareScope, metricQuery.entityId, metricQuery.attributeName, metricQuery.queryFilter));

          case _utils_metric_query__WEBPACK_IMPORTED_MODULE_6__["MetricQueryType"].Types:
            return Promise.resolve(self.getGrafanaListTypes(metricQuery.fiwareScope));

          case _utils_metric_query__WEBPACK_IMPORTED_MODULE_6__["MetricQueryType"].AttributeValue:
            return Promise.resolve(self.getGrafanaListAttributeValue(metricQuery.fiwareScope, metricQuery.entityId, metricQuery.attributeName, metricQuery.queryFilter));

          case _utils_metric_query__WEBPACK_IMPORTED_MODULE_6__["MetricQueryType"].AttributeValueAsMapping:
            return Promise.resolve(self.getGrafanaListAttributeValueAsMapping(metricQuery.fiwareScope, metricQuery.entityId, metricQuery.attributeName, metricQuery.queryFilter));

          case _utils_metric_query__WEBPACK_IMPORTED_MODULE_6__["MetricQueryType"].AttributeValueAsList:
            return Promise.resolve(self.getGrafanaListAttributeValueAsList(metricQuery.fiwareScope, metricQuery.entityId, metricQuery.attributeName, metricQuery.queryFilter));

          case _utils_metric_query__WEBPACK_IMPORTED_MODULE_6__["MetricQueryType"].AttributeName:
            return Promise.resolve(self.getGrafanaListEntityAttributes(metricQuery.fiwareScope, true));

          case _utils_metric_query__WEBPACK_IMPORTED_MODULE_6__["MetricQueryType"].FiwareServices:
            return Promise.resolve(self.getGrafanaListFiwareServices());

          case _utils_metric_query__WEBPACK_IMPORTED_MODULE_6__["MetricQueryType"].FiwareServicePaths:
            return Promise.resolve(self.getGrafanaListFiwareServicePaths(metricQuery.fiwareScope.service));

          default:
            return Promise.resolve([]);
        }
      } else {
        console.log('Error with metrics query');
        return Promise.resolve([]);
      }
    }
  }, {
    key: "testDatasource",
    value: function testDatasource() {
      var self = this;
      return self.doRequest({
        url: self.url + Datasource.ORION_URL_GET_VERSION,
        method: 'GET'
      }).then(function (response) {
        if (response.status === 200) {
          var orionVersion = response.data['orion']['version'];
          return {
            status: 'success',
            message: 'Orion Datasource is OK, Version ' + orionVersion,
            title: 'Success'
          };
        } else {
          return {
            status: 'error',
            message: 'Data source /version is not OK',
            title: 'Error'
          };
        }
      }, function () {
        return {
          status: 'error',
          message: 'Data source /version is not OK',
          title: 'Error'
        };
      });
    }
  }], [{
    key: "getFiwareEntityCollection",
    value: function getFiwareEntityCollection(fiwareScope, attributes, orionEntities) {
      return new _utils_fiware_entity__WEBPACK_IMPORTED_MODULE_5__["FIWAREEntityCollection"](fiwareScope.service, fiwareScope.servicePath, attributes, orionEntities);
    }
  }]);

  return Datasource;
}();
Datasource.DEFAULT_SERVICE_HEADER = 'default';
Datasource.DEFAULT_SERVICE_PATH_HEADER = '/default';
Datasource.ORION_ADMIN_METRICS = '/admin/metrics';
Datasource.ORION_URL_ENTITIES = '/v2/entities';
Datasource.ORION_URL_TYPES = '/v2/types?options=values';
Datasource.ORION_URL_GET_VERSION = '/version';
Datasource.DEFAULT_TYPE_ALL_ENTITIES = 'All';
Datasource.DEFAULT_ATTRIBUTES = 'Default';
Datasource.DEFAULT_ALL_ATTRIBUTES = 'All';
Datasource.DEFAULT_NAME_TIME_COLUMN = 'time';

/***/ }),

/***/ "./module.ts":
/*!*******************!*\
  !*** ./module.ts ***!
  \*******************/
/*! exports provided: Datasource, QueryCtrl, ConfigCtrl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _datasource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./datasource */ "./datasource.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Datasource", function() { return _datasource__WEBPACK_IMPORTED_MODULE_0__["Datasource"]; });

/* harmony import */ var _query_ctrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./query-ctrl */ "./query-ctrl.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "QueryCtrl", function() { return _query_ctrl__WEBPACK_IMPORTED_MODULE_1__["QueryCtrl"]; });

/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./config */ "./config.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ConfigCtrl", function() { return _config__WEBPACK_IMPORTED_MODULE_2__["Config"]; });






/***/ }),

/***/ "./query-ctrl.ts":
/*!***********************!*\
  !*** ./query-ctrl.ts ***!
  \***********************/
/*! exports provided: QueryCtrl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QueryCtrl", function() { return QueryCtrl; });
/* harmony import */ var _utils_query_type__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/query-type */ "./utils/query-type.ts");
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }


var QueryCtrl = /*#__PURE__*/function () {
  function QueryCtrl() {
    _classCallCheck(this, QueryCtrl);

    var self = this;
    self.target.hide = false;
    self.target.target = self.target.target || 'select metric';
    self.target.type = 'table'; // timeseries

    self.requests = Object.keys(_utils_query_type__WEBPACK_IMPORTED_MODULE_0__["QueryType"]);
    self.target.selectedRequest = self.target.selectedRequest || 'Entities';
    self.target.defaultFiwareService = self.target.defaultFiwareService || false;
    self.target.entityType = self.target.entityType || 'All';
    self.target.currentTimeColumn = self.target.currentTimeColumn || false;
    self.target.entityId = self.target.entityId || 'All';
    self.target.attributes = self.target.attributes || 'All';
    self.target.queryFilter = self.target.queryFilter || '';
    self.target.enableTypeSearch = self.target.enableTypeSearch || false;
    self.onChangeInternal();
  }

  _createClass(QueryCtrl, [{
    key: "findMetricsTypesGrafana",
    value: function findMetricsTypesGrafana() {
      var self = this;
      var query = {
        defaultFiwareHeaders: self.target.defaultFiwareService,
        fiwareService: self.target.service,
        fiwareServicePath: self.target.servicePath
      };
      return self.datasource.findMetricsTypesGrafana(query).then(function (typesArray) {
        var options = typesArray;

        if (typesArray !== undefined) {
          options.push({
            text: 'All',
            value: 'All'
          });
        } else {
          options = [{
            text: 'All',
            value: 'All'
          }, {
            text: 'None',
            value: 'None'
          }];
        }

        return options;
      });
    }
  }, {
    key: "findMetricsEntitiesGrafana",
    value: function findMetricsEntitiesGrafana() {
      var self = this;
      var query = {
        defaultFiwareHeaders: self.target.defaultFiwareService,
        fiwareService: self.target.service,
        fiwareServicePath: self.target.servicePath,
        entityType: self.target.entityType
      };
      return self.datasource.findMetricsEntitiesGrafana(query).then(function (entityArray) {
        var options = entityArray;

        if (entityArray !== undefined) {
          options.push({
            text: 'All',
            value: 'All'
          });
        } else {
          options = [{
            text: 'All',
            value: 'All'
          }, {
            text: 'None',
            value: 'None'
          }];
        }

        return options;
      });
    }
  }, {
    key: "findMetricsAttributesGrafana",
    value: function findMetricsAttributesGrafana() {
      var self = this;
      var query = {
        defaultFiwareHeaders: self.target.defaultFiwareService,
        fiwareService: self.target.service,
        fiwareServicePath: self.target.servicePath,
        entityType: self.target.entityType
      };
      return self.datasource.findMetricsAttributesGrafana(query, false).then(function (attributesArray) {
        var options = attributesArray;

        if (attributesArray !== undefined) {
          options.push({
            text: 'Default',
            value: 'Default'
          }, {
            text: 'All',
            value: 'All'
          });
        } else {
          options = [{
            text: 'Default',
            value: 'Default'
          }, {
            text: 'All',
            value: 'All'
          }, {
            text: 'None',
            value: 'None'
          }];
        }

        return options;
      });
    }
  }, {
    key: "reloadEntities",
    value: function reloadEntities() {
      this.onChangeInternal();
    }
  }, {
    key: "onChangeInternal",
    value: function onChangeInternal() {
      this.panelCtrl.refresh();
    }
  }]);

  return QueryCtrl;
}();
QueryCtrl.templateUrl = 'partials/query-editor.html';

/***/ }),

/***/ "./utils/fiware-entity.ts":
/*!********************************!*\
  !*** ./utils/fiware-entity.ts ***!
  \********************************/
/*! exports provided: FIWAREEntity, FIWAREEntityCollection */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FIWAREEntity", function() { return FIWAREEntity; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FIWAREEntityCollection", function() { return FIWAREEntityCollection; });
/* harmony import */ var _fiware_scope__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fiware-scope */ "./utils/fiware-scope.ts");
/* harmony import */ var _grafana_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./grafana-utils */ "./utils/grafana-utils.ts");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }



var FIWAREEntity = /*#__PURE__*/function (_FIWAREScope) {
  _inherits(FIWAREEntity, _FIWAREScope);

  var _super = _createSuper(FIWAREEntity);

  function FIWAREEntity(service, servicePath, type, id, attributes, entityJson) {
    var _this;

    _classCallCheck(this, FIWAREEntity);

    _this = _super.call(this, service, servicePath, type);
    _this.service = service;
    _this.servicePath = servicePath;
    _this.type = type;
    _this.id = id;
    _this.attributes = attributes;
    _this.entityJson = entityJson;
    _this.id = id;
    _this.attributes = attributes;
    _this.entityJson = entityJson;
    return _this;
  }

  _createClass(FIWAREEntity, [{
    key: "toString",
    value: function toString() {
      if (this.attributes && this.attributes.name) {
        return "".concat(this.attributes.name, " (").concat(this.id, ")");
      } else {
        return this.id;
      }
    }
  }], [{
    key: "parseFromJSON",
    value: function parseFromJSON(service, servicePath, entityJson) {
      var attributes = {}; // @ts-ignore

      Object.entries(entityJson).forEach(function (attribute) {
        if (attributes[FIWAREEntity.DEFAULT_NAME_TIME_COLUMN] === undefined && attribute[0] === 'dateModified') {
          attributes[FIWAREEntity.DEFAULT_NAME_TIME_COLUMN] = attribute[1].value;
        } else if (attribute[0] === 'TimeInstant') {
          attributes[FIWAREEntity.DEFAULT_NAME_TIME_COLUMN] = attribute[1].value;
        } else if (attribute[0] !== 'id' && attribute[0] !== 'type') {
          var attributeValue = '-';

          if (attribute[1] instanceof Object) {
            if (attribute[1].type === 'Number' || attribute[1].type === 'Float') {
              attributeValue = parseFloat(attribute[1].value);
            } else if (attribute[1].type === 'Integer') {
              attributeValue = parseInt(attribute[1].value, 10);
            } else if (attribute[1].type === 'Text') {
              attributeValue = String(attribute[1].value);
            } else {
              attributeValue = attribute[1].value;
            }
          } else {
            attributeValue = attribute[1];
          }

          attributes[attribute[0]] = attributeValue;
        }
      });
      return new FIWAREEntity(service, servicePath, entityJson.type, entityJson.id, attributes, entityJson);
    }
  }]);

  return FIWAREEntity;
}(_fiware_scope__WEBPACK_IMPORTED_MODULE_0__["FIWAREScope"]);
FIWAREEntity.DEFAULT_NAME_TIME_COLUMN = 'time';
var FIWAREEntityCollection = /*#__PURE__*/function () {
  function FIWAREEntityCollection(service, servicePath, attributesRequested, entitiesResponse) {
    _classCallCheck(this, FIWAREEntityCollection);

    this.entities = [];
    this.attributesRequested = [];
    var self = this;
    self.NGSIRaw = entitiesResponse;

    if (attributesRequested.length === 0) {
      this.attributesRequested = FIWAREEntityCollection.DEFAULT_ALL_ENTITY_COLUMNS.slice();
    } else {
      this.attributesRequested = attributesRequested;
    }

    entitiesResponse.forEach(function (NGSI_entity) {
      var fiwareEntity = FIWAREEntity.parseFromJSON(service, servicePath, NGSI_entity);
      self.entities.push(fiwareEntity);
    });
  }

  _createClass(FIWAREEntityCollection, [{
    key: "isEmpty",
    value: function isEmpty() {
      return this.entities.length === 0;
    }
  }, {
    key: "getColumnHeaders",
    value: function getColumnHeaders(includeTime) {
      var self = this;
      var columnHeaders = []; // columnHeaders.push('id');
      // columnHeaders.push('type');

      if (self.entities.length > 0) {
        Object.keys(self.entities[0].attributes).forEach(function (key) {
          if (key !== 'dateModified' && key !== 'TimeInstant' && key !== FIWAREEntity.DEFAULT_NAME_TIME_COLUMN) {
            columnHeaders.push(key);
          }
        });
      }

      if (includeTime) {
        columnHeaders.push(FIWAREEntity.DEFAULT_NAME_TIME_COLUMN);
      }

      return columnHeaders;
    }
  }, {
    key: "getEntities",
    value: function getEntities() {
      return this.entities;
    }
  }, {
    key: "getArray",
    value: function getArray() {
      var self = this;
      var entities = [];
      self.entities.forEach(function (entity) {
        entities.push(entity.id);
      });
      return entities;
    }
  }, {
    key: "getGrafanaList",
    value: function getGrafanaList() {
      return _grafana_utils__WEBPACK_IMPORTED_MODULE_1__["GrafanaUtils"].getGrafanaList(this.getArray());
    }
  }, {
    key: "getAttributeValuesArray",
    value: function getAttributeValuesArray(attributeName) {
      var self = this; // @ts-ignore

      if (self.attributesRequested.includes(attributeName)) {
        var attributeValues = [];
        self.entities.forEach(function (entity) {
          attributeValues.push(entity.attributes[attributeName]);
        });
        return attributeValues;
      } else {
        return [];
      }
    }
  }, {
    key: "getAttributeValuesArrayMappingId",
    value: function getAttributeValuesArrayMappingId(attributeName) {
      var self = this; // @ts-ignore

      if (self.attributesRequested.includes(attributeName)) {
        var attributeValuesMapping = [];
        self.entities.forEach(function (entity) {
          attributeValuesMapping.push([entity.attributes[attributeName], entity.id]);
        });
        return attributeValuesMapping;
      } else {
        return [];
      }
    }
  }, {
    key: "getAttributeValuesGrafanaList",
    value: function getAttributeValuesGrafanaList(attributeName) {
      return _grafana_utils__WEBPACK_IMPORTED_MODULE_1__["GrafanaUtils"].getGrafanaList(this.getAttributeValuesArray(attributeName));
    }
  }, {
    key: "getAttributeValuesGrafanaListMappingId",
    value: function getAttributeValuesGrafanaListMappingId(attributeName) {
      return _grafana_utils__WEBPACK_IMPORTED_MODULE_1__["GrafanaUtils"].getGrafanaListMapping(this.getAttributeValuesArrayMappingId(attributeName));
    }
  }, {
    key: "getAttributeValueAsGrafanaList",
    value: function getAttributeValueAsGrafanaList(attributeName) {
      if (this.entities.length !== 1 || this.entities[0].attributes[attributeName] === undefined) {
        return _grafana_utils__WEBPACK_IMPORTED_MODULE_1__["GrafanaUtils"].getGrafanaList([]);
      }

      var arrayAttributeValue = this.entities[0].attributes[attributeName];

      if (!Array.isArray(arrayAttributeValue)) {
        arrayAttributeValue = [arrayAttributeValue];
      }

      return _grafana_utils__WEBPACK_IMPORTED_MODULE_1__["GrafanaUtils"].getGrafanaList(arrayAttributeValue);
    }
  }, {
    key: "getGrafanaTable",
    value: function getGrafanaTable(includeTime, allEntityAttributes) {
      var self = this;
      var columns = ['id', 'type'];
      var rows = [];

      if (this.entities.length === 0) {
        return _grafana_utils__WEBPACK_IMPORTED_MODULE_1__["GrafanaUtils"].getTableObject([], []);
      }

      if (allEntityAttributes) {
        columns = columns.concat(self.getColumnHeaders(includeTime));
      } else {
        columns = columns.concat(self.attributesRequested.slice());

        if (includeTime) {
          columns.push(FIWAREEntity.DEFAULT_NAME_TIME_COLUMN);
        }
      }

      var innerRow = [];
      self.entities.forEach(function (entity) {
        columns.forEach(function (column) {
          if (column === 'id') {
            innerRow.push(entity.id);
          } else if (column === 'type') {
            innerRow.push(entity.type);
          } else if (column === 'time') {
            innerRow.push(new Date(entity.attributes['time']).getTime());
          } else {
            var attribute = entity.attributes[column];

            if (attribute !== undefined) {
              innerRow.push(attribute);
            } else {
              innerRow.push('-');
            }
          }
        });
        rows.push(innerRow);
        innerRow = [];
      });
      return _grafana_utils__WEBPACK_IMPORTED_MODULE_1__["GrafanaUtils"].getTableObject(columns, rows);
    }
  }]);

  return FIWAREEntityCollection;
}();
FIWAREEntityCollection.DEFAULT_ALL_ENTITY_COLUMNS = ['location', 'latitude', 'longitude'];

/***/ }),

/***/ "./utils/fiware-scope-collection.ts":
/*!******************************************!*\
  !*** ./utils/fiware-scope-collection.ts ***!
  \******************************************/
/*! exports provided: FiwareServicesCollection, FiwareServicePathsCollection */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FiwareServicesCollection", function() { return FiwareServicesCollection; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FiwareServicePathsCollection", function() { return FiwareServicePathsCollection; });
/* harmony import */ var _grafana_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./grafana-utils */ "./utils/grafana-utils.ts");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }


var FiwareServicesCollection = /*#__PURE__*/function () {
  function FiwareServicesCollection(fiwareServicesResponse) {
    _classCallCheck(this, FiwareServicesCollection);

    this.fiwareServices = [];
    var self = this;

    for (var _i = 0, _Object$entries = Object.entries(fiwareServicesResponse.services); _i < _Object$entries.length; _i++) {
      var _Object$entries$_i = _slicedToArray(_Object$entries[_i], 1),
          key = _Object$entries$_i[0];

      self.fiwareServices.push(key);
    }
  }

  _createClass(FiwareServicesCollection, [{
    key: "getArray",
    value: function getArray() {
      return this.fiwareServices;
    }
  }, {
    key: "getGrafanaList",
    value: function getGrafanaList() {
      return _grafana_utils__WEBPACK_IMPORTED_MODULE_0__["GrafanaUtils"].getGrafanaList(this.getArray());
    }
  }]);

  return FiwareServicesCollection;
}();
var FiwareServicePathsCollection = /*#__PURE__*/function () {
  function FiwareServicePathsCollection(fiwareService, fiwareServicePathsResponse) {
    _classCallCheck(this, FiwareServicePathsCollection);

    this.fiwareService = fiwareService;
    this.fiwareServicePaths = [];
    var self = this;
    self.fiwareService = fiwareService;

    for (var _i2 = 0, _Object$entries2 = Object.entries(fiwareServicePathsResponse.services[self.fiwareService].subservs); _i2 < _Object$entries2.length; _i2++) {
      var _Object$entries2$_i = _slicedToArray(_Object$entries2[_i2], 1),
          key = _Object$entries2$_i[0];

      self.fiwareServicePaths.push('/' + key);
    }
  }

  _createClass(FiwareServicePathsCollection, [{
    key: "getArray",
    value: function getArray() {
      return this.fiwareServicePaths;
    }
  }, {
    key: "getGrafanaList",
    value: function getGrafanaList() {
      return _grafana_utils__WEBPACK_IMPORTED_MODULE_0__["GrafanaUtils"].getGrafanaList(this.getArray());
    }
  }]);

  return FiwareServicePathsCollection;
}();

/***/ }),

/***/ "./utils/fiware-scope.ts":
/*!*******************************!*\
  !*** ./utils/fiware-scope.ts ***!
  \*******************************/
/*! exports provided: FIWAREScope */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FIWAREScope", function() { return FIWAREScope; });
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

var FIWAREScope = /*#__PURE__*/function () {
  function FIWAREScope(service, servicePath, type) {
    _classCallCheck(this, FIWAREScope);

    this.service = service;
    this.servicePath = servicePath;
    this.type = type;
    this.service = service;
    this.servicePath = servicePath;
    this.type = type;
  }

  _createClass(FIWAREScope, [{
    key: "isCompleted",
    value: function isCompleted() {
      return this.service !== null && this.servicePath !== null && this.type !== null && this.type !== 'empty';
    }
  }], [{
    key: "getFiwareHeaders",
    value: function getFiwareHeaders(service, servicePath) {
      var headers = {};
      headers[FIWAREScope.ORION_SERVICE_HEADER] = service;
      headers[FIWAREScope.ORION_SERVICEPATH_HEADER] = servicePath;
      headers['Content-Type'] = '';
      return headers;
    }
  }]);

  return FIWAREScope;
}();
FIWAREScope.ORION_SERVICE_HEADER = 'fiware-service';
FIWAREScope.ORION_SERVICEPATH_HEADER = 'fiware-servicepath';

/***/ }),

/***/ "./utils/fiware-type.ts":
/*!******************************!*\
  !*** ./utils/fiware-type.ts ***!
  \******************************/
/*! exports provided: FIWARETypeCollection */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FIWARETypeCollection", function() { return FIWARETypeCollection; });
/* harmony import */ var _grafana_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./grafana-utils */ "./utils/grafana-utils.ts");
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }


var FIWARETypeCollection = /*#__PURE__*/function () {
  function FIWARETypeCollection(service, servicePath, typeResponse) {
    _classCallCheck(this, FIWARETypeCollection);

    this.types = [];
    var self = this;
    typeResponse.forEach(function (type) {
      self.types.push(type);
    });
  }

  _createClass(FIWARETypeCollection, [{
    key: "getArray",
    value: function getArray() {
      return this.types;
    }
  }, {
    key: "getGrafanaList",
    value: function getGrafanaList() {
      return _grafana_utils__WEBPACK_IMPORTED_MODULE_0__["GrafanaUtils"].getGrafanaList(this.getArray());
    }
  }]);

  return FIWARETypeCollection;
}();

/***/ }),

/***/ "./utils/grafana-utils.ts":
/*!********************************!*\
  !*** ./utils/grafana-utils.ts ***!
  \********************************/
/*! exports provided: GrafanaUtils */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GrafanaUtils", function() { return GrafanaUtils; });
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

var GrafanaUtils = /*#__PURE__*/function () {
  function GrafanaUtils() {
    _classCallCheck(this, GrafanaUtils);
  }

  _createClass(GrafanaUtils, null, [{
    key: "setEmptyGrafanaTable",
    value: function setEmptyGrafanaTable(tableData) {
      tableData.data[0].rows = [];
      return tableData;
    }
  }, {
    key: "getGrafanaList",
    value: function getGrafanaList(variableList) {
      var grafanaVariableList = [];
      variableList.forEach(function (variable) {
        grafanaVariableList.push({
          text: variable,
          value: variable
        });
      });
      return grafanaVariableList;
    }
  }, {
    key: "getGrafanaListMapping",
    value: function getGrafanaListMapping(variableTextValueList) {
      var grafanaVariableList = [];
      variableTextValueList.forEach(function (textValue) {
        grafanaVariableList.push({
          text: textValue[0],
          value: textValue[1]
        });
      });
      return grafanaVariableList;
    }
  }, {
    key: "getTableObject",
    value: function getTableObject(columnsString, rows) {
      var columns = [];
      columnsString.forEach(function (column) {
        columns.push({
          text: column
        });
      });
      return [{
        columns: columns,
        rows: rows,
        type: 'table'
      }];
    }
  }]);

  return GrafanaUtils;
}();

/***/ }),

/***/ "./utils/metric-query.ts":
/*!*******************************!*\
  !*** ./utils/metric-query.ts ***!
  \*******************************/
/*! exports provided: MetricQueryType, MetricQuery */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MetricQueryType", function() { return MetricQueryType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MetricQuery", function() { return MetricQuery; });
/* harmony import */ var _fiware_scope__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fiware-scope */ "./utils/fiware-scope.ts");
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }


var MetricQueryType;

(function (MetricQueryType) {
  MetricQueryType["Entities"] = "Entities";
  MetricQueryType["Types"] = "Types";
  MetricQueryType["AttributeValue"] = "AttributeValue";
  MetricQueryType["AttributeValueAsList"] = "AttributeValueAsList";
  MetricQueryType["AttributeName"] = "AttributeName";
  MetricQueryType["FiwareServices"] = "FiwareServices";
  MetricQueryType["FiwareServicePaths"] = "FiwareServicePaths";
  MetricQueryType["AttributeValueAsMapping"] = "AttributeValueAsMapping";
})(MetricQueryType || (MetricQueryType = {}));

var MetricQuery = /*#__PURE__*/function () {
  function MetricQuery(request, service, servicePath, type, entityId, attributeName, queryFilter) {
    _classCallCheck(this, MetricQuery);

    this.request = request;
    this.fiwareScope = new _fiware_scope__WEBPACK_IMPORTED_MODULE_0__["FIWAREScope"](service, servicePath, type);
    this.entityId = MetricQuery.DEFAULT_ALL_VALUE;

    if (entityId !== undefined) {
      this.entityId = entityId;
    }

    this.attributeName = MetricQuery.DEFAULT_ALL_VALUE;

    if (attributeName !== undefined) {
      this.attributeName = attributeName;
    }

    this.queryFilter = '';

    if (queryFilter !== undefined) {
      this.queryFilter = queryFilter;
    }
  }

  _createClass(MetricQuery, [{
    key: "isComplete",
    value: function isComplete() {
      return this.request !== undefined && this.fiwareScope !== undefined && this.fiwareScope.isCompleted();
    }
  }, {
    key: "toShortString",
    value: function toShortString() {
      return 'simple';
    }
  }], [{
    key: "parseFromJSON",
    value: function parseFromJSON(json) {
      var metricQuery = new MetricQuery();
      metricQuery.request = json.request;

      if (json.fiwareScope === undefined) {
        metricQuery.fiwareScope = new _fiware_scope__WEBPACK_IMPORTED_MODULE_0__["FIWAREScope"](undefined, undefined, undefined);
      } else {
        metricQuery.fiwareScope = new _fiware_scope__WEBPACK_IMPORTED_MODULE_0__["FIWAREScope"](json.fiwareScope.service, json.fiwareScope.servicePath, json.fiwareScope.type);
      }

      if (json.entityId !== undefined) {
        metricQuery.entityId = json.entityId;
      }

      if (json.attributeName !== undefined) {
        metricQuery.attributeName = json.attributeName;
      }

      if (json.queryFilter !== undefined) {
        metricQuery.queryFilter = json.queryFilter;
      }

      return metricQuery;
    }
  }]);

  return MetricQuery;
}();
MetricQuery.DEFAULT_ALL_VALUE = 'All';

/***/ }),

/***/ "./utils/query-type.ts":
/*!*****************************!*\
  !*** ./utils/query-type.ts ***!
  \*****************************/
/*! exports provided: QueryType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QueryType", function() { return QueryType; });
var QueryType;

(function (QueryType) {
  QueryType["Entities"] = "Entities";
})(QueryType || (QueryType = {}));

/***/ })

/******/ })});;
//# sourceMappingURL=module.js.map